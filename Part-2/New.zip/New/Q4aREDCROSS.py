from sense_hat import SenseHat
from time import sleep

sense = SenseHat()
sense.clear()

# Define colors
RED = (255, 0, 0)      # Red color for the cross
WHITE = (255, 255, 255)  # White for off (background)

# Create an 8x8 grid initially all white
cross = [WHITE for i in range(64)]

# Draw vertical line of the cross (column 3 and 4)
for row in range(8):
    cross[row * 8 + 3] = RED  # Column 3
    cross[row * 8 + 4] = RED  # Column 4

# Draw horizontal line of the cross (row 3 and 4)
for col in range(8):
    cross[3 * 8 + col] = RED  # Row 3
    cross[4 * 8 + col] = RED  # Row 4

# Display the pattern
sense.set_pixels(cross)

# Keep it displayed until cleared
try:
    while True:
        sleep(1)
except KeyboardInterrupt:
    sense.clear()
