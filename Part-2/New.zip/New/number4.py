import time
import grovepi
from grove_rgb_lcd import *
import datetime

# Connections
button = 6  # D6
buzzer = 7  # D7

grovepi.pinMode(button, "INPUT")
grovepi.pinMode(buzzer, "OUTPUT")

# Set your alarm time (current time + offset for testing)
# Example: alarm after 30 seconds from now
now = datetime.datetime.now()
alarm_time = now + datetime.timedelta(seconds=7)

print("Alarm set for:", alarm_time.strftime("%H:%M:%S"))
setText("")

while True:
    try:
        current_time = datetime.datetime.now()
        hh = current_time.hour
        mm = current_time.minute
        ss = current_time.second

        # Display current time on LCD
        setRGB(0, 255, 0)
        text = "Time:" + str(hh) + "h " + str(mm) + "m " + str(ss) + "s"
        setText(text)

        # Check alarm condition
        if current_time >= alarm_time:
            setRGB(0, 0, 255)  # Blue
            setText("MIIT!")
            grovepi.digitalWrite(buzzer, 1)
            
            buzzer_time = 0
            while buzzer_time < 5:
                buzzer_time += 1
                time.sleep(1)
                
                # Stop ringing if button pressed
                if grovepi.digitalRead(button) == 1:
                    grovepi.digitalWrite(buzzer, 0)
                    setRGB(255, 0, 0)
                    setText("Stopped Early")
                    time.sleep(2)
                    exit()
            
            grovepi.digitalWrite(buzzer, 0)
            setRGB(255, 255, 255)
            setText("Done")
            break

        time.sleep(1)
        
    except KeyboardInterrupt:
        grovepi.digitalWrite(buzzer, 0)
        break
    except IOError:
        print("Error")
