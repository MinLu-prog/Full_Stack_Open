import time
import grovepi
from telegram import Bot

# Connections
sound_sensor = 0        # port A0
light_sensor = 1        # port A1
temperature_sensor = 2  # port D2
led = 3                 # port D3

intro_str = "DI Lab's"

# Telegram setup (replace with your token and chat ID)
BOT_TOKEN = '8025179842:AAH0Ns0-IH57PLbGOh74EeuxY01MCESiN8o'
CHAT_ID = '1528325410'
bot = Bot(token=BOT_TOKEN)

grovepi.pinMode(led,"OUTPUT")
grovepi.analogWrite(led,255)  #turn led to max to show readiness

while True:

    try:

        # Get value from light sensor
        light_intensity = grovepi.analogRead(light_sensor)

        # Give PWM output to LED
        grovepi.analogWrite(led, int(light_intensity/4))

        # Get sound level
        sound_level = grovepi.analogRead(sound_sensor)

        time.sleep(0.5)

        # Get value from temperature sensor
        [t,h]=[0,0]
        [t,h] = grovepi.dht(temperature_sensor,0)

        # Prepare message string
        out_str ="%s Temp: %d C, Humidity: %d, Light: %d, Sound: %d" % (intro_str,t,h,int(light_intensity/10),sound_level)
        print(out_str)

        # Send message to Telegram instead of tweeting
        bot.send_message(chat_id=CHAT_ID, text=out_str)

    except IOError:
        print("Error")
    except KeyboardInterrupt:
        exit()
    except Exception as e:
        print("Telegram error or refusal: {}".format(e))

    time.sleep(60)