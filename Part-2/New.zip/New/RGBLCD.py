import time
import grovepi
from grove_rgb_lcd import *

# Define pin numbers
button = 2
buzzer = 5

# Set pin modes
grovepi.pinMode(buzzer, "OUTPUT")
grovepi.pinMode(button, "INPUT")

try:
    while True:
        current_time = time.strftime("%H:%M:%S")

        if grovepi.digitalRead(button) == 1:
            grovepi.digitalWrite(buzzer, 1)
            setText("
