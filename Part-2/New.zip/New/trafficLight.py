import time
import grovepi

# Grove port connections
green_led = 2        # D2 - Traffic Green LED
red_led = 3          # D3 - Traffic Red LED
pedestrian_led = 4   # D4 - Pedestrian LED
button = 5           # D5 - Push Button

# Set pin modes
grovepi.pinMode(green_led, "OUTPUT")
grovepi.pinMode(red_led, "OUTPUT")
grovepi.pinMode(pedestrian_led, "OUTPUT")
grovepi.pinMode(button, "INPUT")

# Initial state
grovepi.digitalWrite(green_led, 1)
grovepi.digitalWrite(red_led, 0)
grovepi.digitalWrite(pedestrian_led, 0)

print("System ready. Waiting for button press...")

while True:
    try:
        button_state = grovepi.digitalRead(button)

        if button_state == 1:
            # Button pressed: switch traffic to red, pedestrian to ON
            grovepi.digitalWrite(green_led, 0)
            grovepi.digitalWrite(red_led, 1)
            grovepi.digitalWrite(pedestrian_led, 1)
            print("Button pressed. Red light ON, pedestrian walk signal ON.")

        else:
            # Button not pressed: reset to initial state
            grovepi.digitalWrite(green_led, 1)
            grovepi.digitalWrite(red_led, 0)
            grovepi.digitalWrite(pedestrian_led, 0)

        time.sleep(0.1)

    except KeyboardInterrupt:
        grovepi.digitalWrite(green_led, 0)
        grovepi.digitalWrite(red_led, 0)
        grovepi.digitalWrite(pedestrian_led, 0)
        print("Program stopped.")
        break

    except IOError:
        print("IO Error")
