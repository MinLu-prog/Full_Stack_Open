import time
from grove_rgb_lcd import *
import grovepi

# Pin assignment
green_led = 2  # Green traffic light
red_led = 3    # Red traffic light
ultra_sonic = 0

# Pin mode setup
grovepi.pinMode(green_led, "OUTPUT")
grovepi.pinMode(red_led, "OUTPUT")
grovepi.pinMode(ultra_sonic, "INPUT")

# Initial state
grovepi.digitalWrite(green_led,0)
grovepi.digitalWrite(red_led, 0)

while True:
    try:
        distance = ultrasonicRead(ultra_sonic)
        print("Distance : ", distance)

        if distance > 10:
            grovepi.digitalWrite(green_led, 0)
            grovepi.digitalWrite(red_led, 1)
            time.sleep(5)
        else:
            grovepi.digitalWrite(green_led, 1)
            grovepi.digitalWrite(red_led, 0)
            time.sleep(5)

    except:
        print("Error")