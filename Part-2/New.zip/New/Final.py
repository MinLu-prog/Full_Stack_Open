#!/usr/bin/env python3
# Cooktop Guardian - clipboard-friendly ASCII version
# - NTC thermistor (analog) read + Beta formula
# - PIR resets safety timer
# - Actuator (LED or relay) turned OFF when hot + no motion
# - Sends a Discord message when actuator is turned OFF
# - Supports environment variables (recommended) or hard-coded token option

import os
import time
import math
import asyncio
import signal
import sys

import grovepi
import discord
from discord import Intents

# -----------------------------
# CONFIG SECTION (edit here)
# -----------------------------
# If True, the code will use hard-coded token and channel below.
# If False, it will use environment variables DISCORD_TOKEN and DISCORD_CHANNEL_ID.
USE_HARDCODED_TOKEN = True

# Only used if USE_HARDCODED_TOKEN = True
DISCORD_TOKEN_HARDCODED = "MTM5NzgwNDU3NjEwNjc0NTk5Nw.G0LfXZ.76b6NmmeOD6m-JUDMO790nXE3ilQp3DDXJIl8M"   # string, e.g. "NjA..."
DISCORD_CHANNEL_ID_HARDCODED = 1397822147614998611       # integer channel id

# Behavior / thresholds (tweak for demo or production)
TEMP_THRESHOLD_C = float(os.getenv("TEMP_THRESHOLD_C", "55.0"))   # degrees Celsius threshold
SAFETY_DURATION_S = int(os.getenv("SAFETY_DURATION_S", "60"))     # seconds for demo (60s)
SENSOR_POLL_INTERVAL = float(os.getenv("SENSOR_POLL_INTERVAL", "1.0"))  # seconds between reads
ALERT_COOLDOWN_S = int(os.getenv("ALERT_COOLDOWN_S", "300"))      # seconds between alerts

# NTC thermistor calibration (change if you know exact values)
NTC_BETA = float(os.getenv("NTC_BETA", "3975"))
NTC_R_SERIES = float(os.getenv("NTC_R_SERIES", "10000.0"))
ADC_MAX = 1023.0

# Hardware mapping (Grove ports)
TEMP_SENSOR_A_PORT = 2     # A2
PIR_DIGITAL_PORT = 4       # D4
ACTUATOR_DIGITAL = 3       # D3

# If True, actuator will re-enable automatically when temp is safe (NOT recommended)
AUTO_REENABLE = False

# -----------------------------
# Token selection & validation
# -----------------------------
if USE_HARDCODED_TOKEN:
    DISCORD_TOKEN = DISCORD_TOKEN_HARDCODED
    DISCORD_CHANNEL_ID = DISCORD_CHANNEL_ID_HARDCODED
else:
    DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
    ch_env = os.getenv("DISCORD_CHANNEL_ID")
    if ch_env is not None:
        try:
            DISCORD_CHANNEL_ID = int(ch_env)
        except ValueError:
            DISCORD_CHANNEL_ID = None
    else:
        DISCORD_CHANNEL_ID = None

if not DISCORD_TOKEN:
    raise RuntimeError("Discord token not provided. Set USE_HARDCODED_TOKEN=True or set DISCORD_TOKEN env var.")

if not DISCORD_CHANNEL_ID:
    raise RuntimeError("Discord channel id not provided. Set USE_HARDCODED_TOKEN=True or set DISCORD_CHANNEL_ID env var.")

# -----------------------------
# Setup GrovePi pins
# -----------------------------
grovepi.pinMode(TEMP_SENSOR_A_PORT, "INPUT")
grovepi.pinMode(PIR_DIGITAL_PORT, "INPUT")
grovepi.pinMode(ACTUATOR_DIGITAL, "OUTPUT")

# Start with actuator ON (simulate stove ON)
ACTUATOR_ON = True
try:
    grovepi.digitalWrite(ACTUATOR_DIGITAL, 1)
except Exception as e:
    print("Warning: could not set actuator initial state:", e)

# -----------------------------
# Thermistor read helper
# -----------------------------
def read_ntc_temperature_c(adc_pin=TEMP_SENSOR_A_PORT, beta=NTC_BETA, r_series=NTC_R_SERIES):
    try:
        raw = grovepi.analogRead(adc_pin)
    except Exception:
        return None

    # invalid ADC extremes
    if raw <= 0 or raw >= ADC_MAX:
        return None

    try:
        r_therm = (r_series * raw) / (ADC_MAX - raw)
        R0 = 10000.0
        T0 = 298.15
        inv_T = (1.0 / T0) + (1.0 / beta) * math.log(r_therm / R0)
        temp_k = 1.0 / inv_T
        temp_c = temp_k - 273.15
        return temp_c
    except Exception:
        return None

# -----------------------------
# Discord client and monitoring
# -----------------------------
intents = Intents.default()
client = discord.Client(intents=intents)

_high_temp_start = None
_safety_deadline = None
_last_motion_time = time.monotonic()
_last_alert_time = 0.0

async def sensor_loop_and_logic(channel):
    global _high_temp_start, _safety_deadline, _last_motion_time, ACTUATOR_ON, _last_alert_time

    print("Sensor loop started. Threshold={:.1f} C, SafetyDuration={}s, PollInterval={}s".format(
        TEMP_THRESHOLD_C, SAFETY_DURATION_S, SENSOR_POLL_INTERVAL))

    try:
        while True:
            now = time.monotonic()

            # Read PIR
            try:
                pir_val = grovepi.digitalRead(PIR_DIGITAL_PORT)
            except Exception:
                pir_val = 0

            # Read temperature
            temp_c = read_ntc_temperature_c()

            # Motion handling
            if pir_val == 1:
                _last_motion_time = now
                if _safety_deadline is not None:
                    _safety_deadline = now + SAFETY_DURATION_S
                print("[{}] Motion detected -> timer reset".format(time.strftime("%H:%M:%S")))

            # Temperature handling
            if temp_c is not None:
                print("[{}] Temp = {:.2f} C, PIR={}".format(time.strftime("%H:%M:%S"), temp_c, pir_val))
                if temp_c >= TEMP_THRESHOLD_C:
                    if _high_temp_start is None:
                        _high_temp_start = now
                        _safety_deadline = now + SAFETY_DURATION_S
                        print("High temperature detected -> safety timer started")
                else:
                    if _high_temp_start is not None:
                        print("Temperature fell below threshold -> clearing safety timer")
                    _high_temp_start = None
                    _safety_deadline = None

                    if AUTO_REENABLE and not ACTUATOR_ON:
                        try:
                            grovepi.digitalWrite(ACTUATOR_DIGITAL, 1)
                            ACTUATOR_ON = True
                            print("Auto re-enabled actuator (temp safe).")
                        except Exception as e:
                            print("Failed to re-enable actuator:", e)
            else:
                print("[{}] Temperature read failed or out of range".format(time.strftime("%H:%M:%S")))

            # Check safety deadline
            if _safety_deadline is not None:
                remaining = _safety_deadline - now
                if remaining <= 0:
                    if ACTUATOR_ON:
                        try:
                            grovepi.digitalWrite(ACTUATOR_DIGITAL, 0)
                        except Exception as e:
                            print("Warning: could not write actuator OFF:", e)
                        ACTUATOR_ON = False
                        print("SAFETY TIMEOUT reached: actuator turned OFF (no motion while hot)")

                        # Send Discord alert once per cooldown
                        if now - _last_alert_time >= ALERT_COOLDOWN_S:
                            try:
                                alert_msg = ("Cooktop Guardian: No motion detected while the cooktop "
                                             "remained hot. Actuator turned OFF for safety.")
                                await channel.send(alert_msg)
                                _last_alert_time = now
                                print("Discord alert sent.")
                            except Exception as e:
                                print("Failed to send Discord alert:", e)
                        else:
                            print("Alert suppressed due to cooldown.")
                else:
                    print(" Safety timer remaining: {} s".format(int(remaining)))

            await asyncio.sleep(SENSOR_POLL_INTERVAL)

    except asyncio.CancelledError:
        print("Sensor loop cancelled (cleanup).")
    finally:
        try:
            grovepi.digitalWrite(ACTUATOR_DIGITAL, 0)
        except Exception:
            pass
        print("Sensor loop terminated; actuator forced OFF in cleanup.")

@client.event
async def on_ready():
    print("Discord client ready as {}".format(client.user))
    channel = client.get_channel(DISCORD_CHANNEL_ID)
    if channel is None:
        try:
            channel = await client.fetch_channel(DISCORD_CHANNEL_ID)
        except Exception as e:
            print("Could not find or fetch channel:", e)
            await client.close()
            return
    client.loop.create_task(sensor_loop_and_logic(channel))

# Graceful shutdown
def shutdown(sig, frame):
    print("Received exit signal; closing client...")
    try:
        asyncio.get_event_loop().create_task(client.close())
    except Exception:
        pass
    sys.exit(0)

signal.signal(signal.SIGINT, shutdown)
signal.signal(signal.SIGTERM, shutdown)

def main():
    try:
        client.run(DISCORD_TOKEN)
    except KeyboardInterrupt:
        print("Interrupted by user.")
    except Exception as e:
        print("Discord client terminated with exception:", e)
    finally:
        try:
            grovepi.digitalWrite(ACTUATOR_DIGITAL, 0)
        except Exception:
            pass
        print("Cooktop Guardian exiting.")

if __name__ == "__main__":
    main()
