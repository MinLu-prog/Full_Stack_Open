import time
from grovepi import *
import math
buzzer_pin = 2 #for buzzer
button = 4 #for button
pinMode(buzzer_pin,"OUTPUT")
pinMode(button,"INPUT")
while True:
    try:
        button_status = digitalRead(button)
        if button_status:
            digitalWrite(buzzer_pin,1)
        else:
            digitalWrite(buzzer_pin,0)
        
    except keyboardInterrupt:
        digitalWrite(buzzer_pin,0)
        break;
    except (IOError,TypeError) as e:
        print ("Error")