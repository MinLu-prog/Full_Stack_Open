from sense_hat import SenseHat
from time import sleep
import random

sense = SenseHat()

while True:
    temp = sense.get_temperature()
    pressure = sense.get_pressure()
    humidity = sense.get_humidity()

    color1 = [random.randint(0,255) for _ in range(3)]
    color2 = [random.randint(0,255) for _ in range(3)]
    color3 = [random.randint(0,255) for _ in range(3)]

    sense.show_message(f"Temp:{temp:.1f}", text_colour=color1)
    sense.show_message(f"Pres:{pressure:.1f}", text_colour=color2)
    sense.show_message(f"Hum:{humidity:.1f}", text_colour=color3)
    sleep(1)
