# Countdown Alarm Example
# Hardware connections:
# - RGB LCD -> I2C port
# - Buzzer -> D4
# - Push Button -> D3

import time
import grovepi
from grove_rgb_lcd import *

BUZZER = 4
BUTTON = 3

grovepi.pinMode(BUZZER, "OUTPUT")
grovepi.pinMode(BUTTON, "INPUT")

countdown = 10  # start value in seconds

print("Countdown Alarm started...")

try:
    while countdown >= 0:
        setRGB(0, 255, 0)  # Green background
        setText("Countdown:\n{:02d}".format(countdown))
        print("Time left:", countdown)

        if countdown == 0:
            print("Alarm triggered!")
            setRGB(255, 0, 0)  # Red background
            setText("ALERT!\n00")

            start_time = time.time()
            while time.time() - start_time < 5:  # 5 seconds buzzer
                grovepi.digitalWrite(BUZZER, 1)

                if grovepi.digitalRead(BUTTON) == 1:
                    grovepi.digitalWrite(BUZZER, 0)
                    print("Alarm stopped by button.")
                    break

                time.sleep(0.1)

            grovepi.digitalWrite(BUZZER, 0)
            break

        time.sleep(1)
        countdown -= 1

except KeyboardInterrupt:
    grovepi.digitalWrite(BUZZER, 0)
    setText("Stopped")
    setRGB(0, 0, 0)
    print("Program stopped.")
