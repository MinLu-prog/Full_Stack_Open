import time
import grovepi
import discord
import asyncio
import math

# === Pin Setup ===
temperature_sensor = 2   # A2 for temp sensor (change if needed)
led = 3                  # D3 for relay/LED
pir_sensor = 4           # D4 for PIR motion sensor

# === Config ===
intro_str = "DI Lab's"
DISCORD_TOKEN = "MTM5NzgwNDU3NjEwNjc0NTk5Nw.G0LfXZ.76b6NmmeOD6m-JUDMO790nXE3ilQp3DDXJIl8M"
CHANNEL_ID = 1397822147614998611  # integer, not string

TEMP_THRESHOLD = 80  # Example value - adjust based on your sensor calibration
NO_MOTION_LIMIT = 50# 20 m9inutes in seconds

# === Setup GrovePi Pins ===
grovepi.pinMode(temperature_sensor, "INPUT")
grovepi.pinMode(led, "OUTPUT")
grovepi.pinMode(pir_sensor, "INPUT")

grovepi.digitalWrite(led, 1)  # Assume ON initially

# === Discord Client ===
client = discord.Client()

last_motion_time = time.time()  # Track last motion

def read_temperature():
    sensor_value = grovepi.analogRead(temperature_sensor)

    # Avoid division by zero or invalid values
    if sensor_value <= 0 or sensor_value >= 1023:
        return None

    try:
        resistance = (1023 - sensor_value) * 100.0 / sensor_value
        temperature = 1.0 / (math.log(resistance / 10000.0) / 3975 + 1 / 298.15) - 273.15
        return temperature
    except (ValueError, ZeroDivisionError):
        return None
    
@client.event
async def on_ready():
    global last_motion_time 
    print("Logged in as {}".format(client.user.name))
    channel = client.get_channel(CHANNEL_ID)
    if channel is None:
        print("Could not find channel. Check your CHANNEL_ID.")
        return

    while True:
        try:
            
            # === PIR motion detection ===
            pir_value = grovepi.digitalRead(pir_sensor)
            temperature = read_temperature()
            if pir_value > 0:  # motion detected
                print("Motion detected!")
                last_motion_time = time.time()
            else:
                print("No Motion detected!")
        

            if temperature is not None:
                print("Temperature: {:.2f} C".format(temperature))

            # If hot and no one around for 15 minutes
            if temperature > TEMP_THRESHOLD and (time.time() - last_motion_time) > NO_MOTION_LIMIT:
                grovepi.digitalWrite(led, 0)  # turn OFF LED/relay
                print("No motion for 20 min & Overheating! LED OFF")

                message = "Caution! No motion for 20min and electric pan is overheating. Electricity is cut off."
                print("Sending: " + message)
                await channel.send(message)
                time.sleep(60)# Prevent repeated messages
            else:
                 grovepi.digitalWrite(led, 1)  # keep ON
                 print("Safe or motion detected. LED ON")

            time.sleep(5)

        except KeyboardInterrupt:
            grovepi.digitalWrite(led, 0)
            print("Program stopped")
            break
        except IOError:
            print("Sensor error")


client.run(DISCORD_TOKEN)