import time
import grovepi

# Connect the Grove Sound Sensor to analog port A0
# SIG, NC, VCC, GND
sound_sensor = 0

# Connect the Grove LED to digital port D5
# SIG, NC, VCC, GND
led = 5

grovepi.pinMode(sound_sensor, "INPUT")
grovepi.pinMode(led, "OUTPUT")

threshold_value = 600

while True:
    try:
        # Read the sound level
        sensor_value = grovepi.analogRead(sound_sensor)

        # If loud, illuminate LED, otherwise turn it off
        if sensor_value > threshold_value:
            grovepi.digitalWrite(led, 1)
        else:
            grovepi.digitalWrite(led, 0)

        print("sensor_value = %d" % sensor_value)
        time.sleep(0.5)

    except IOError:
        print("Error")
