from picamera import PiCamera
from time import sleep

# Initialize the camera
camera = PiCamera()

# Set camera resolution (optional)
camera.resolution = (1280, 720)

# Start recording
camera.start_recording('/home/pi/video.h264')
print("Recording started...")

# Record for 10 seconds
sleep(10)

# Stop recording
camera.stop_recording()
print("Recording stopped.")

# Release the camera
camera.close()
