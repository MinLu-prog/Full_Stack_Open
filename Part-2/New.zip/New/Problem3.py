# problem3_alt.py
# Alternate version of Problem 3 (DHT + Sound + LCD + Button)

import time
import grovepi
import grove_rgb_lcd as lcd

# Pin connections
DHT_PIN = 7       # digital port D7
DHT_TYPE = 0      # 0 = DHT11, 1 = DHT22
SOUND_PIN = 1     # analog port A1
BUTTON_PIN = 2    # digital port D2

# Setup
grovepi.pinMode(BUTTON_PIN, "INPUT")

def show_temp_humidity():
    """Display temperature and humidity on LCD"""
    try:
        [temp, hum] = grovepi.dht(DHT_PIN, DHT_TYPE)
        if temp is not None and hum is not None:
            lcd.setText("Temp:{:.1f}C\nHum:{:.1f}%".format(temp, hum))
        else:
            lcd.setText("Sensor error")
    except Exception as e:
        lcd.setText("Read error\n" + str(e))

def show_sound():
    """Display sound sensor value on LCD"""
    try:
        sound_val = grovepi.analogRead(SOUND_PIN)
        lcd.setText("Sound Value:\n{}".format(sound_val))
    except Exception as e:
        lcd.setText("Sound error\n" + str(e))

def main():
    lcd.setRGB(0, 0, 255)   # Blue background (LCD on I2C port)
    print("Problem 3 started (LCD blue, DHT + Sound + Button)")

    while True:
        # check button
        if grovepi.digitalRead(BUTTON_PIN) == 1:
            show_sound()
            time.sleep(1.5)   # show sound for 1.5s
        else:
            show_temp_humidity()
            time.sleep(1.5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        lcd.setText("Goodbye")
        lcd.setRGB(0,0,0)
        print("Stopped by user")
