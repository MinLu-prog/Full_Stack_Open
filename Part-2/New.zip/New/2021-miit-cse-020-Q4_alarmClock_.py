from grovepi import *
from grove_rgb_lcd import *
import time
from datetime import datetime

button = 3   # D4
buzzer = 4   # D2
alarm_time = "00:00:20" 

pinMode(button, "INPUT")
pinMode(buzzer, "OUTPUT")

try:
    while True:
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        setText("Time:\n{}".format(current_time))
        setRGB(0, 255, 0)  

        if current_time == alarm_time:
            setRGB(0, 255,0)
            setText("Welcome!")
            digitalWrite(buzzer, 1)

            start = time.time()
            while time.time() - start < 5:
                if digitalRead(button):
                    break
                time.sleep(0.1)

            digitalWrite(buzzer, 0)
            setText("OFF!")
            time.sleep(2)

        time.sleep(1)

except KeyboardInterrupt:
    digitalWrite(buzzer, 0)
    setText("Stopped manually")