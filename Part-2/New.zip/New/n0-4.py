import time
import grovepi
from grove_rgb_lcd import *

# Grove connections
buzzer = 4        # D4
button = 3        # D3
grovepi.pinMode(buzzer, "OUTPUT")
grovepi.pinMode(button, "INPUT")

# Initial timer (20 seconds)
hours = 0
minutes = 0
seconds = 20

# Threshold value (when buzzer should ring)
THRESHOLD = 0   # when timer reaches 00:00:00

def format_time(h, m, s):
    #"""Format time into hh:mm:ss"""
    return ("{h:02d}","{m:02d}","{s:02d}")

print("Countdown Timer Started...")
setRGB(0, 0, 255)  # Green background

# Countdown loop
while True:
    try:
        # Display time on LCD
        current_time = format_time(hours, minutes, seconds)
        setText_norefresh("Time Left:\n" + current_time)
        print("Time Left:", current_time)

        time.sleep(1)

        # Decrease time
        if seconds > 0:
            seconds -= 1
        elif minutes > 0:
            minutes -= 1
            seconds = 59
        elif hours > 0:
            hours -= 1
            minutes = 59
            seconds = 59
        else:
   
            setRGB(0, 255, 0)  # Blue background
            setText("Welcome!")
            print("Welcome! Buzzer ON")

            buzzer_start = time.time()
            while time.time() - buzzer_start < 5:
                grovepi.digitalWrite(buzzer, 1)

             
                if grovepi.digitalRead(button):
                    grovepi.digitalWrite(buzzer, 0)
                    print("Buzzer stopped by button")
                    setText("Stopped Early")
                    break

            grovepi.digitalWrite(buzzer, 0)  # Ensure buzzer is off
            break

    except KeyboardInterrupt:
        grovepi.digitalWrite(buzzer, 0)
        setText("")
        break
    except IOError:
        print("I2C Error")

