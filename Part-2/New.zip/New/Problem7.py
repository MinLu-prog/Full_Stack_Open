# toll_counter.py
import time
import grovepi
import grove_rgb_lcd as lcd
from grovepi import ultrasonicRead

USONIC_PIN = 4    # D4
RELAY_PIN = 5     # D5
#LCD = True

TRIGGER_DISTANCE_CM = 10    # adjust for your lane
DEBOUNCE_SECONDS = 2        # ignore repeats for this long after a count

grovepi.pinMode(RELAY_PIN, "OUTPUT")

try:
    count = 0
    last_count_time = 0
    lcd.setRGB(255,255,255)
    lcd.setText("Count: 0")
    print("Toll counter running. Threshold:", TRIGGER_DISTANCE_CM, "cm")
    while True:
        try:
            dist = ultrasonicRead(USONIC_PIN)
        except Exception:
            # fallback if grovepi.ultrasonicRead isn't available
            dist = grovepi.ultrasonicRead(USONIC_PIN)

        print("Dist:", dist)
        if dist != -1 and dist <= TRIGGER_DISTANCE_CM and time.time() - last_count_time > DEBOUNCE_SECONDS:
            # vehicle detected
            count += 1
            last_count_time = time.time()
            # activate relay briefly
            grovepi.digitalWrite(RELAY_PIN, 1)
            lcd.setText("Count: {}\n{}".format(count, dist))
            time.sleep(0.5)
            grovepi.digitalWrite(RELAY_PIN, 0)
            print("Vehicle counted. Total:", count)
        time.sleep(0.1)

except KeyboardInterrupt:
    pass
finally:
    grovepi.digitalWrite(RELAY_PIN, 0)
    lcd.setText("Stopped\nCount: {}".format(count))
    print("Final count:", count)
