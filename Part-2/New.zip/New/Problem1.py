# led_cycle_button.py
import time
import grovepi

# pins
LED_PINS = [2, 3, 4]      # D2, D3, D4
BUTTON_PIN = 7            # D7

# setup
for p in LED_PINS:
    grovepi.pinMode(p, "OUTPUT")
grovepi.pinMode(BUTTON_PIN, "INPUT")

running = False
last_button = 0
debounce = 0.2

try:
    print("Ready. Press button to start/stop cycling.")
    while True:
        btn = grovepi.digitalRead(BUTTON_PIN)
        if btn == 1 and time.time() - last_button > debounce:
            running = not running
            last_button = time.time()
            print("Running:", running)
            # turn all off when stopping
            if not running:
                for p in LED_PINS:
                    grovepi.digitalWrite(p, 0)

        if running:
            for p in LED_PINS:
                # if stopped mid-cycle break
                if not running:
                    break
                # turn this LED on, others off
                for other in LED_PINS:
                    grovepi.digitalWrite(other, 1 if other == p else 0)
                time.sleep(0.5)   # adjust speed here

        time.sleep(0.05)

except KeyboardInterrupt:
    pass
finally:
    for p in LED_PINS:
        grovepi.digitalWrite(p, 0)
    print("Exiting.")
