import time
import grovepi

# Connect LEDs to digital ports
led1 = 2  # D2
led2 = 3  # D3
led3 = 4  # D4

# Set pin modes
grovepi.pinMode(led1, "OUTPUT")
grovepi.pinMode(led2, "OUTPUT")
grovepi.pinMode(led3, "OUTPUT")

while True:
    try:
        # Turn on LED 1
        grovepi.digitalWrite(led1, 1)
        grovepi.digitalWrite(led2, 0)
        grovepi.digitalWrite(led3, 0)
        print("LED 1 ON")
        time.sleep(1)

        # Turn on LED 2
        grovepi.digitalWrite(led1, 0)
        grovepi.digitalWrite(led2, 1)
        grovepi.digitalWrite(led3, 0)
        print("LED 2 ON")
        time.sleep(1)

        # Turn on LED 3
        grovepi.digitalWrite(led1, 0)
        grovepi.digitalWrite(led2, 0)
        grovepi.digitalWrite(led3, 1)
        print("LED 3 ON")
        time.sleep(1)

    except KeyboardInterrupt:
        # Turn off all LEDs before exiting
        grovepi.digitalWrite(led1, 0)
        grovepi.digitalWrite(led2, 0)
        grovepi.digitalWrite(led3, 0)
        print("Program stopped.")
        break

    except IOError:
        print("IO Error")
