from sense_hat import SenseHat
import time

sense = SenseHat()
sense.clear()

# Define colors
B = [0, 0, 255]   # Blue (raindrop)
E = [255, 255, 255]     # Black (empty)

# Raindrop image (8x8)
raindrop = [
    E, E, E, B, E, E, E, E,
    E, E, B, B, B, E, E, E,
    E, B, B, B, B, B, E, E,
    E, B, B, B, B, B, E, E,
    E, B, B, B, B, B, E, E,
    E, E, B, B, B, E, E, E,
    E, E, E, E, E, E, E, E,
    E, E, E, E, E, E, E, E
]

# Display raindrop
sense.set_pixels(raindrop)

# Display for 5 seconds
time.sleep(10)
sense.clear()

