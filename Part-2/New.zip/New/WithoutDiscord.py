# -*- coding: utf-8 -*-
import time
import math
import grovepi

# === GrovePi Port Setup ===
pir_sensor = 8        # PIR motion sensor on D8
led = 4               # LED on D4
temp_sensor = 0       # Analog Temperature Sensor on A0

grovepi.pinMode(pir_sensor, "INPUT")
grovepi.pinMode(led, "OUTPUT")
# === Settings ===
TEMP_THRESHOLD = 30   # Celsius, set threshold temperature
NO_MOTION_LIMIT = 15 # 15 minutes = 900 seconds

last_motion_time = time.time()

# Turn LED ON at start (simulate pan being ON)
grovepi.digitalWrite(led, 1)

def read_temperature():
    sensor_value = grovepi.analogRead(temp_sensor)

    # Avoid division by zero or invalid values
    if sensor_value <= 0 or sensor_value >= 1023:
        return None

    try:
        resistance = (1023 - sensor_value) * 10000.0 / sensor_value
        temperature = 1.0 / (math.log(resistance / 10000.0) / 3975 + 1 / 298.15) - 273.15
        return temperature
    except (ValueError, ZeroDivisionError):
        return None

while True:
    try:
        # Read PIR motion sensor
        motion = grovepi.digitalRead(pir_sensor)
        # Read analog temperature
        temperature = read_temperature()

        if motion:
            last_motion_time = time.time()
            print("Motion detected in kitchen.")
        else:
            print("No motion detected.")

        if temperature is not None:
            print("Temperature: {:.2f} C".format(temperature))

            # If hot and no one around for 15 minutes
            if temperature > TEMP_THRESHOLD and (time.time() - last_motion_time) > NO_MOTION_LIMIT:
                grovepi.digitalWrite(led, 0)  # Turn off LED
                print("Warning! Pan left ON, no one in kitchen for 15 min. LED turned OFF automatically.")
                time.sleep(60)  # Prevent repeated messages
        else:
            print("Temperature reading error (sensor value invalid)")

        time.sleep(5)

    except KeyboardInterrupt:
        grovepi.digitalWrite(led, 0)
        break
    except Exception as e:
        print("Error:", e)
