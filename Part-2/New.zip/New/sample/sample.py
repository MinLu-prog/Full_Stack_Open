Sample something 
