import time
import grovepi

led1 = 3
led2 = 4
led3 = 7

btn_pin = 2

grovepi.pinMode(led1, "OUTPUT")
grovepi.pinMode(led2, "OUTPUT")
grovepi.pinMode(led3, "OUTPUT")

grovepi.pinMode(btn_pin, "INPUT")

while True:
    btn = grovepi.digitalRead(btn_pin)
    flag = False
    if btn:
        flag = True
    
    while flag:
        grovepi.digitalWrite(led1, 1)
        grovepi.digitalWrite(led2, 0)
        grovepi.digitalWrite(led3, 0)
        print("green")
        time.sleep(1)
        
        grovepi.digitalWrite(led1, 0)
        grovepi.digitalWrite(led2, 1)
        grovepi.digitalWrite(led3, 0)
        print("red")
        time.sleep(1)
        
        grovepi.digitalWrite(led1, 0)
        grovepi.digitalWrite(led2, 0)
        grovepi.digitalWrite(led3, 1)
        print("blue")
        time.sleep(1)