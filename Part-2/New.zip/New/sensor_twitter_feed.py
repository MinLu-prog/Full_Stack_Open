import time
import grovepi
import telegram
from telegram.ext import Updater, CommandHandler

# Connections
sound_sensor = 0        # port A0
light_sensor = 1        # port A1
temperature_sensor = 2  # port D2
led = 3                 # port D3

intro_str = "DI Lab's"

grovepi.pinMode(led, "OUTPUT")
grovepi.analogWrite(led, 255)

# Telegram setup
bot_token = '8179903436:AAE9LM1yeNKoIEOI_JKQVM0z6ecnA-UUa3M'
chat_id = '1958940742'  # Replace with your chat ID

bot = telegram.Bot(token=bot_token)

running = True

def start(update, context):
    global running
    running = True
    update.message.reply_text("Sensor monitoring started.")

def stop(update, context):
    global running
    running = False
    update.message.reply_text("Sensor monitoring stopped.")

updater = Updater(bot_token, use_context=True)
dp = updater.dispatcher
dp.add_handler(CommandHandler("start", start))
dp.add_handler(CommandHandler("stop", stop))
updater.start_polling()

# Sensor Loop
while True:
    if running:
        try:
            light = grovepi.analogRead(light_sensor)
            grovepi.analogWrite(led, light // 4)
            sound = grovepi.analogRead(sound_sensor)
            time.sleep(0.5)
            [t, h] = grovepi.dht(temperature_sensor, 0)

            out_str = "{} Temp: {} C, Humidity: {} %, Light: {}, Sound: {}".format(
                intro_str, t, h, light // 10, sound)
            print(out_str)
            bot.send_message(chat_id=chat_id, text=out_str)

        except IOError:
            print("Sensor Error")
        except Exception as e:
            print("Error:", e)
    time.sleep(10)