import time
import grovepi
import math
import discord
import asyncio

# === GrovePi Sensor Ports ===
sound_sensor = 0        # A0
light_sensor = 1        # A1
temperature_sensor = 2  # D2
led = 3                 # D3

intro_str = "DI Lab's"
DISCORD_TOKEN = 'MTM5NzgwNDU3NjEwNjc0NTk5Nw.G0LfXZ.76b6NmmeOD6m-JUDMO790nXE3ilQp3DDXJIl8M'  # <-- Replace this!
CHANNEL_ID = 1397822147614998611      # <-- Replace this (as an integer, no quotes)

# === Setup GrovePi Pins ===
grovepi.pinMode(led, "OUTPUT")
grovepi.analogWrite(led, 255)

# === Create Discord Client ===
client = discord.Client()

@client.event
async def on_ready():
    print(" Logged in as {}".format(client.user.name))
    channel = client.get_channel(CHANNEL_ID)
    if channel is None:
        print("L Could not find channel. Check your CHANNEL_ID.")
        return

    while True:
        try:
            # Read sensors
            light_intensity = grovepi.analogRead(light_sensor)
            sound_level = grovepi.analogRead(sound_sensor)
            [t, h] = grovepi.dht(temperature_sensor, 0)

            if math.isnan(t) or math.isnan(h):
                raise ValueError("Invalid temperature or humidity reading")

            # Adjust LED brightness
            grovepi.analogWrite(led, light_intensity // 4)

            # Format message (using .format for Python 3.5)
            message = "{} - Temp: {}C, Humidity: {}%, Light: {}, Sound: {}".format(
                intro_str, int(t), int(h), light_intensity // 10, sound_level
            )

            print("Sending: " + message)
            await channel.send(message)

        except Exception as e:
            print("L Error: {}".format(e))

        await asyncio.sleep(60)

client.run(DISCORD_TOKEN)