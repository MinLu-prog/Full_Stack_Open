import time
import grovepi
from grove_rgb_lcd import *

# Ports
dht_sensor = 7        # D7 port
sound_sensor = 0      # A0 port
button = 2            # D2 port

grovepi.pinMode(button, "INPUT")

while True:
    try:
        # Read DHT sensor
        [temp, hum] = grovepi.dht(dht_sensor, 0)

        # Default display: Temp + Humidity
        setRGB(0, 0, 255)   # Blue background
        setText("Temp: %.1fC\nHum: %.1f%%" % (temp, hum))

        # Check if button is pressed
        if grovepi.digitalRead(button):
            sound_val = grovepi.analogRead(sound_sensor)
            setText("Sound Level:\n%d" % sound_val)

        time.sleep(1)

    except KeyboardInterrupt:
        setText("Exiting...")
        break
    except IOError:
        print("Sensor Error")
