import time
from grovepi import *
from grove_rgb_lcd import *

# Connections
ultrasonic_ranger = 4   # D4 (Ultrasonic sensor)
relay = 3               # D3 (Relay)
count = 0               # Vehicle counter

pinMode(relay, "OUTPUT")

threshold = 15  # vehicle within 15 cm

while True:
    try:
        # Measure distance
        distance = ultrasonicRead(ultrasonic_ranger)

        # If vehicle is close enough
        if distance > 0 and distance < threshold:
            count += 1
            digitalWrite(relay, 1)   # turn ON relay (open gate)

            # Show count on LCD
            setRGB(0, 255, 0)
            setText("Vehicle Count:\n{}".format(count))
            print("Vehicle detected, total =", count)

            time.sleep(2)
        else:
            digitalWrite(relay, 0)   # turn OFF relay (close gate)

        time.sleep(0.1)

    except KeyboardInterrupt:
        digitalWrite(relay, 0)
        setText("")
        break
    except IOError:
        print("Error reading sensor")