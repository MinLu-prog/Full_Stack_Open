from grovepi import *
import time

led1 = 2     #green
led2 = 7    # yellow
led3 = 4     # Red
led4 = 5 # p-green(walk)
led5 = 8 # p-red (don't walk)


# Set pin modes
pinMode(led1, "OUTPUT")
pinMode(led2, "OUTPUT")
pinMode(led3, "OUTPUT")
pinMode(led4, "OUTPUT")
pinMode(led5, "OUTPUT")



try:
    while True:
        digitalWrite(led1,1)
        time.sleep(15)
        digitalWrite(led2,1)
        time.sleep(5)
        digitalWrite(led3,0)
        digitalWrite(led4,0)
        digitalWrite(led5,1)
        time.sleep(25)
        
        digitalWrite(led1,0)
        digitalWrite(led2,0)
        digitalWrite(led3,1)
        time.sleep(20)
        digitalWrite(led5,0)
        digitalWrite(led4,1)
        time.sleep(15)
        
        
     
    
except KeyboardInterrupt:
    digitalWrite(led1, 0)
    digitalWrite(led2, 0)
    digitalWrite(led3, 0)
    digitalWrite(led4, 0)
    digitalWrite(led5, 0)