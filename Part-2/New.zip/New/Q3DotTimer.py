from sense_hat import SenseHat
from time import sleep

sense = SenseHat()
sense.clear()

def dot_timer():
    # Initial red dots (64 pixels)
    for x in range(8):
        for y in range(8):
            sense.set_pixel(x, y, (255, 0, 0))  # Red
    
    # Count down by turning dots green
    for i in range(64):
        x = i % 8
        y = i // 8
        sense.set_pixel(x, y, (0, 255, 0))  # Green
        sleep(1)  # 1 second per dot
    
    # Flash 10 times
    for _ in range(10):
        sense.clear((255, 255, 255))  # White
        sleep(0.2)
        sense.clear()
        sleep(0.2)

dot_timer()
