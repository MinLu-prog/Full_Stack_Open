
from grovepi import *
from grove_rgb_lcd import *
from time import sleep
from math import isnan

dht_sensor_port = 7 # connect the DHt sensor to port 7
dht_sensor_type = 0 # use 0 for the blue-colored sensor and 1 for the white-colored sensor

button=3
sound_sensor=0
pinMode(sound_sensor,'INPUT')
pinMode(button,'INPUT')
setRGB(0,0,255)

while True:
  try:
        
    [ temp,hum ] = dht(dht_sensor_port,dht_sensor_type)
    
    t = str(temp)
    h = str(hum)
    
    sound_value=analogRead(sound_sensor)
    s=str(sound_value)
    button_value=digitalRead(button)
    if(button_value):
       
       # print("sound_value = %d" % sound_value)
        setText("Sound_value input is" + s +"\n")
        time.sleep(1)
    else:
        setText("Temp:" + t + "C\n" + "Humidity :" + h + "%")
        #print("temp =", temp, "C\thumidity =", hum,"%")
        time.sleep(1)

  except (IOError, TypeError) as e:
    print(str(e))
    # and since we got a type error
    # then reset the LCD's text
    setText("")

  except KeyboardInterrupt as e:
    print(str(e))
    # since we're exiting the program
    # it's better to leave the LCD with a blank text
    setText("")
    break

  # wait some time before re-updating the LCD
  