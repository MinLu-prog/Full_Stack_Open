import time
import grovepi

LDR_PIN = 0      # A0
LED_PIN = 2      # D2
R_FIXED = 10000.0  # 10k pull resistor used in the divider
THRESHOLD = 400   # adjust: if sensor value < THRESHOLD -> dark (depends on your setup)

grovepi.pinMode(LED_PIN, "OUTPUT")

def sensor_to_resistance(sensor_value):
    
    if sensor_value == 0:
        return float('inf')
    return (1023.0 - sensor_value) * R_FIXED / float(sensor_value)

try:
    print("Auto light: LED on when dark. Ctrl+C to stop.")
    max_resistance = 0.0
    while True:
        val = grovepi.analogRead(LDR_PIN)
        res = sensor_to_resistance(val)
        if res != float('inf') and res > max_resistance:
            max_resistance = res
        print("Sensor:", val, "Resistance(ohm):", round(res, 1))
        if val < THRESHOLD:
            grovepi.digitalWrite(LED_PIN, 1)
            print("Dark -> LED ON")
        else:
            grovepi.digitalWrite(LED_PIN, 0)
            print("Bright -> LED OFF")
        time.sleep(0.5)
except KeyboardInterrupt:
    print("\nStopped. Peak observed resistance (ohm):", round(max_resistance,1))
finally:
    grovepi.digitalWrite(LED_PIN, 0)
