import time
import grovepi

# Ports
light_sensor = 2 
led = 4              

grovepi.pinMode(light_sensor, "INPUT")

threshold = 50

try:
    while True:
        sensor_value = grovepi.analogRead(light_sensor)

        resistance = (float)(1023 - sensor_value) * 10 / sensor_value
        
        print("Light Sensor Value =", sensor_value, " Resistance =", resistance)

        if sensor_value < threshold:
            grovepi.digitalWrite(led, 1)  # Turn ON LED
        else:
            grovepi.digitalWrite(led, 0)  # Turn OFF LED

        time.sleep(1)
    
except KeyboardInterrupt:
    digitalWrite(led, 0)