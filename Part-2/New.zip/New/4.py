import time
import grovepi
from grove_rgb_lcd import *
from math import isnan

# Grove connections
button = 3   # Push button on D6
buzzer = 2    # Buzzer on D5

grovepi.pinMode(button, "INPUT")
grovepi.pinMode(buzzer, "OUTPUT")

# Predefined threshold in seconds (example: 10 sec = 00:00:10)
THRESHOLD = 10  

# Initialize
hours = 0
minutes = 0
seconds = 20

setRGB(0, 0, 255)  # Green background
setText("Timer Ready")

print("Count-up timer starting...")

start_time = time.time()

while True:
    try:
        # Calculate elapsed time
        elapsed = int(time.time() - start_time)
        hours = elapsed // 3600
        minutes = (elapsed % 3600) // 60
        seconds = elapsed % 60

        # Show hh:mm:ss on LCD
        lcd_time = "%02d:%02d:%02d" % (hours, minutes, seconds)
        setText_norefresh("Time: %s" % lcd_time)

        # Check if reached threshold
        if elapsed >= THRESHOLD:
            setRGB(0, 255, 0)  # Blue background
            setText("Welcome!")  # LCD message
            buzzer_on = True
            start_buzzer = time.time()

            while buzzer_on:
                grovepi.digitalWrite(buzzer, 1)  # Buzzer ON
                time.sleep(0.1)

                # If button pressed  stop buzzer immediately
                if grovepi.digitalRead(button):
                    buzzer_on = False

                # If 5s passed  stop buzzer automatically
                if time.time() - start_buzzer >= 5:
                    buzzer_on = False

            # Turn buzzer OFF
            grovepi.digitalWrite(buzzer, 0)

            # Reset threshold to a far future to stop repeated buzzing
            THRESHOLD = float('inf')

        time.sleep(1)

    except KeyboardInterrupt:
        grovepi.digitalWrite(buzzer, 0)
        setText("")
        break
    except IOError:
        print("I2C Error")
