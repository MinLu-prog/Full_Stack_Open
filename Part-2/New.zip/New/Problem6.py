import time
import grovepi

# Connect LED to a PWM pin (e.g., D5 supports PWM on GrovePi)
led = 3
grovepi.pinMode(led, "OUTPUT")

try:
    while True:
        # Fade in
        for brightness in range(0, 256, 5):  # 0 to 255
            grovepi.analogWrite(led, brightness)
            time.sleep(0.02)  # Adjust speed of fading

        # Fade out
        for brightness in range(255, -1, -5):
            grovepi.analogWrite(led, brightness)
            time.sleep(0.02)

except KeyboardInterrupt:
    grovepi.analogWrite(led, 0)  # Turn off LED
    print("Program stopped")
