import time
from grovepi import *


led1=2
led2=3
led3=4

button=5

pinMode(led1,"OUTPUT")
pinMode(led2,"OUTPUT")
pinMode(led3,"OUTPUT")
pinMode(button,"INPUT")



while True:
    try:
        button_state=digitalRead(button)
        if button_state:
            digitalWrite(led1,1)
            digitalWrite(led2,0)
            digitalWrite(led3,0)
            print('LED_1 ON & LED_2 OFF & LED_3_OFF')
            time.sleep(3)
            digitalWrite(led1,0)
            digitalWrite(led2,1)
            digitalWrite(led3,0)
            print('LED_1 OFF & LED_2 ON & LED_3_OFF')
            time.sleep(3)
            digitalWrite(led1,0)
            digitalWrite(led2,0)
            digitalWrite(led3,1)
            print('LED_1 OFF & LED_2 OFF & LED_3_ON')
            time.sleep(3)
            
        else:
            digitalWrite(led1,0)
            digitalWrite(led2,0)
            digitalWrite(led3,0)
            print('LED_1 OFF & LED_2 OFF & LED_3_OFF')
         

    except KeyboardInterrupt:   # Turn LED off before stopping
        digitalWrite(led1,0)
        digitalWrite(led2,0)
        digitalWrite(led3,0)
        break
    except IOError:             # Print "Error" if communication error encountered
        print ("Error")

