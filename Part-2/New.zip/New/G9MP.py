# -*- coding: utf-8 -*-
import time
import math
import requests
import grovepi

# === GrovePi Port Setup ===
pir_sensor = 8        # PIR motion sensor on D8
led = 4               # LED on D4
temp_sensor = 0       # Analog Temperature Sensor on A0

grovepi.pinMode(pir_sensor, "INPUT")
grovepi.pinMode(led, "OUTPUT")

# === Discord Webhook URL ===
DISCORD_WEBHOOK = "https://discord.com/api/webhooks/YOUR_WEBHOOK_URL"

# === Settings ===
TEMP_THRESHOLD = 60    # Celsius, set threshold temperature
NO_MOTION_LIMIT = 900  # 15 minutes = 900 seconds

last_motion_time = time.time()

def send_discord_alert(message):
    payload = {"content": message}
    try:
        requests.post(DISCORD_WEBHOOK, json=payload)
        print("Discord message sent!")
    except Exception as e:
        print("Error sending to Discord:", e)

def read_temperature():
    # Formula from Grove Analog Temperature Sensor datasheet
    sensor_value = grovepi.analogRead(temp_sensor)
    resistance = (1023 - sensor_value) * 10000.0 / sensor_value
    temperature = 1.0 / (math.log(resistance / 10000.0) / 3975 + 1 / 298.15) - 273.15
    return temperature

while True:
    try:
        # Read PIR motion sensor
        motion = grovepi.digitalRead(pir_sensor)
        # Read analog temperature
        temperature = read_temperature()

        if motion:
            last_motion_time = time.time()
            print("Motion detected in kitchen.")
        else:
            print("No motion detected.")

        print("Temperature: {:.2f} C".format(temperature))

        # If hot and no one around for 15 minutes
        if temperature > TEMP_THRESHOLD and (time.time() - last_motion_time) > NO_MOTION_LIMIT:
            grovepi.digitalWrite(led, 0)  # Turn off LED
            send_discord_alert("Warning! Pan left ON, no one in kitchen for 15 min. LED turned OFF automatically.")
            time.sleep(60)  # Avoid spamming Discord

        time.sleep(2)

    except KeyboardInterrupt:
        grovepi.digitalWrite(led, 0)
        break
    except Exception as e:
        print("Error:", e)
