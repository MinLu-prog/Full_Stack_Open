import time
import grovepi

# Pin setup
ultrasonic_ranger = 4   # Ultrasonic sensor connected to D4
relay = 5               # Relay connected to D5

vehicle_count = 0
vehicle_detected = False
detection_range = 15  # distance in cm to detect vehicle

# Set relay pin as output
grovepi.pinMode(relay, "OUTPUT")

print("Toll Gate System Started")

while True:
    try:
        # Read distance from ultrasonic sensor
        distance = grovepi.ultrasonicRead(ultrasonic_ranger)

        if distance > 0 and distance < detection_range:
            if not vehicle_detected:
                vehicle_detected = True
                vehicle_count += 1
                grovepi.digitalWrite(relay, 1)  # Open gate
                print("Vehicle Detected! Count:", vehicle_count)
        else:
            vehicle_detected = False
            grovepi.digitalWrite(relay, 0)      # Close gate

        time.sleep(0.2)

    except KeyboardInterrupt:
        grovepi.digitalWrite(relay, 0)
        print("\nSystem Stopped")
        break
    except IOError:
        print("Error reading sensor")