import time
import grovepi

light_sensor = 0
threshold = 10
led = 4

grovepi.pinMode(light_sensor, "INPUT")

while True:
    try:
        sensor_value = grovepi.analogRead(light_sensor)
        resistance = float(1023 - sensor_value) * 10 / sensor_value

        if resistance > threshold:
            grovepi.digitalWrite(led, 1)
        else:
            grovepi.digitalWrite(led, 0)

        time.sleep(0.5)

    except IOError:
        print("Error")
