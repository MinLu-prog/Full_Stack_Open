from sense_hat import SenseHat
from time import sleep

sense = SenseHat()

# Function to show number in red or green
def show_number(n, color):
    sense.show_letter(str(n), text_colour=color)
    sleep(1)

# Count down: 8,6,4,2,0 in red
for i in range(8, -1, -2):
    show_number(i, (255, 0, 0))  # Red

# Count up: 0,2,4,6,8 in green
for i in range(0, 9, 2):
    show_number(i, (0, 255, 0))  # Green

sense.clear()
