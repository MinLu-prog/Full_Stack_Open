# alarm_clock.py
import time
from datetime import datetime
import grovepi
import grove_rgb_lcd as lcd

BUTTON_PIN = 2
BUZZER_PIN = 5
grovepi.pinMode(BUTTON_PIN, "INPUT")
grovepi.pinMode(BUZZER_PIN, "OUTPUT")

ALARM_TIME = "09:20:00"   # set alarm HH:MM:SS

def now_str():
    return datetime.now().strftime("%H:%M:%S")

try:
    lcd.setRGB(255,255,255)
    ringing = False
    while True:
        cur = now_str()
        lcd.setText(cur)
        if cur == ALARM_TIME and not ringing:
            ringing = True
            lcd.setText("Ringing!\n" + cur)
            lcd.setRGB(0,0,255)
            grovepi.digitalWrite(BUZZER_PIN, 1)
            start = time.time()
            while time.time() - start < 5:
                if grovepi.digitalRead(BUTTON_PIN) == 1:
                    break
                time.sleep(0.05)
            grovepi.digitalWrite(BUZZER_PIN, 0)
            lcd.setRGB(255,255,255)
        time.sleep(0.8)
except KeyboardInterrupt:
    pass
finally:
    grovepi.digitalWrite(BUZZER_PIN, 0)
    lcd.setText("Alarm stopped")
