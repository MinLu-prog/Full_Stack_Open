from picamera import PiCamera
from PIL import Image, ImageChops
import time

# Initialize Pi Camera
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 10

# Allow camera to warm up
time.sleep(2)

def capture_image(filename):
    """ Captures an image and saves it to the specified filename """
    camera.capture(filename, format='jpeg')

def detect_motion(image1, image2, threshold=20):
    """ Compare two images and detect motion """
    img1 = Image.open(image1).convert('L')  # Convert to grayscale
    img2 = Image.open(image2).convert('L')

    # Calculate absolute difference
    diff = ImageChops.difference(img1, img2)
    diff_data = diff.getdata()

    # Count pixels with significant difference
    changed_pixels = sum(1 for pixel in diff_data if pixel > threshold)
    
    # If enough pixels have changed, motion is detected
    return changed_pixels > 500  # Adjust this number based on sensitivity

# Continuous monitoring
while True:
    capture_image("frame1.jpg")
    time.sleep(1)  # Wait before capturing next frame
    capture_image("frame2.jpg")

    if detect_motion("frame1.jpg", "frame2.jpg"):
        print("Motion detected!")

    # Optional: Adjust sleep time based on required sensitivity
    time.sleep(1)
