import time
import requests
from grovepi import *
from grove_rgb_lcd import *
import grovepi

# --- Pin setup ---
U1 = 2      # Ultrasonic 1
U2 = 3      # Ultrasonic 2
BTN1 = 7    # Button 1
BTN2 = 8    # Button 2
ARM  = 4    # Arm/Disarm toggle button
BUZ  = 5    # Buzzerx
LED  = 6    # LED

USE_TELEGRAM = True
TELEGRAM_BOT_TOKEN = "8300123654:AAG9OenxQdSfgnax9qjrzIsZKpOozAaV4ac"
TELEGRAM_CHAT_ID = "1828246556"


def lcd_init():
    setRGB(0, 255, 0)  
    setText("System inactive") 
    time.sleep(1)

def update_lcd(message):
    setText(message)


def tg_send(text):
    if not USE_TELEGRAM:
        print("[TELEGRAM DISABLED] {}".format(text))
        return
    url = "https://api.telegram.org/bot{}/sendMessage".format(TELEGRAM_BOT_TOKEN)
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": text}
    try:
        r = requests.post(url, json=payload, timeout=6)
        print("[TELEGRAM REPLY] Status Code: {}, Response: {}".format(r.status_code, r.text)) 
        if r.status_code != 200 or '"ok":true' not in r.text:
            print("[TELEGRAM WARNING] Check token/chat_id or open bot and press Start.")
        update_lcd(text)  
    except Exception as e:
        print("[TELEGRAM EXCEPTION] {}".format(str(e)))


# --- Setup pins ---
for p in (BTN1, BTN2, ARM):
    grovepi.pinMode(p, "INPUT")
for p in (BUZ, LED):
    grovepi.pinMode(p, "OUTPUT")

def is_pressed(pin):
    try:
        return grovepi.digitalRead(pin) == 1
    except:
        return False

def set_output(pin, state):
    try:
        grovepi.digitalWrite(pin, 1 if state else 0)
    except:
        pass

def read_ultra(pin):
    try:
        d = grovepi.ultrasonicRead(pin)
        return d if d and 0 < d < 300 else None
    except:
        return None

# --- Thresholds ---
NEAR1_CM = 30.0
NEAR2_CM = 30.0
ALARM_DURATION_S = 4

def main():
    print("Guardian Gate starting...")
    system_active = False
    last_arm_state = False
    last_msg_time = 0
    last_alarm_time = 0

    set_output(BUZ, False)
    set_output(LED, False)

    lcd_init()

    try:
        while True:
            # --- Arm/Disarm toggle ---
            arm_now = is_pressed(ARM)
            if arm_now and not last_arm_state:
                system_active = not system_active
                status = "ACTIVE" if system_active else "STOPPED"
                print("[SYSTEM] {}".format(status))
                tg_send("Guardian Gate is now {}.".format(status))
                update_lcd("System: {}".format(status))  
                if not system_active:
                    set_output(BUZ, False)
                    set_output(LED, False)
                time.sleep(0.25)  # debounce
            last_arm_state = arm_now

            if not system_active:
                time.sleep(0.2)
                continue

            # --- Read sensors ---
            u1 = read_ultra(U1)
            u2 = read_ultra(U2)
            b1 = is_pressed(BTN1)
            b2 = is_pressed(BTN2)

            print("U1={}cm, U2={}cm, BTN1={}, BTN2={}, ARM={}".format(u1, u2, b1, b2, arm_now))

            both_near = (u1 is not None and u1 < NEAR1_CM) and (u2 is not None and u2 < NEAR2_CM)

            t_now = time.time()

            # --- Case A: only ultrasonic detects human ---
            if both_near and (t_now - last_msg_time > 8):
                tg_send("Someone is in front of the door.")
                print("[INFO] Sent: Someone is in front of the door.")
                last_msg_time = t_now

            # --- Case B: ultrasonic + button pressed ---
            if both_near and (b1 or b2) and (t_now - last_alarm_time > 10):
                tg_send("Intruder confirmed! LED/Buzzer activated.")
                print("[ALARM] Human + button detected")
                set_output(LED, True)
                set_output(BUZ, True)
                update_lcd("Intruder Detected!")  # Update LCD with alarm message
                time.sleep(ALARM_DURATION_S)
                set_output(LED, False)
                set_output(BUZ, False)
                last_alarm_time = time.time()

            time.sleep(0.2)

    except KeyboardInterrupt:
        pass
    finally:
        set_output(BUZ, False)
        set_output(LED, False)
        print("Exiting cleanly.")

if __name__ == "__main__":
    main()

