import grovepi

try:
    print("GrovePi has firmware version: %s" % grovepi.version())
except KeyboardInterrupt:
    print("KeyboardInterrupt")
except IOError:
    print("Error")
